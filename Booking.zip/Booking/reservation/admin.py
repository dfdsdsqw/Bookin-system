from django.contrib import admin

#dkld
from .models import Room, Booking

admin.site.register(Room)
admin.site.register(Booking)

